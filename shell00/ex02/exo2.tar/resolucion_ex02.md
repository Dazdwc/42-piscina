Para este ejercicio vamos a necesitar entender algo muy básico de bash: la creación y visualización de archivos.
para esto nos vamos a servir de 2 comandos:

> - `touch`: para crear el archivo vacío y cambiar la fecha.
> - `truncate`: para cambiar el peso del archivo.
> - `tar`: para comprimir el archivo y que no pierda el formato al subirlo.
> - `chmod`: para cambiar los derechos sobre el archivo.
> - `ls`: para listar los archivos.
> - `rm`: para subir lo que pide explicitamente el ejercicio y borrar el resto.
> - `mkdir`: para crear directorios.
> - `ln`: para hacer los hard y symbolic links

Una vez descargado el repositorio y creada la carpeta ex01:

> 1. Vamos por los directorios, si nos fijamos en el enunciado tanto el test0 como el test2 tienen una `d` al principio de la los permisos `drwx--xr-x`, esto nos indica que se trata de un directorio:
>   ```bash
>   mkdir test0 test2
>   ```
> 2. creamos los archivo test1, test3 y test4 que no tienen dependencias:
>   ```bash
>   touch test1 test3 test4
>   ```
> 3. Ahora procederemos a hacer el softlink (test6): 
>   ```bash
>   ln -s test0 test6
>   ```
>4. Ahora toca el peso de los archivos:
> 
>   ```bash
>   truncate -s 4 test1
>   truncate -s 1 test3
>   truncate -s 2 test4
>   ```
>5. Ahora crearemos la fecha de los archivos, con cuidado que el test6 es un softlink, entonces debemos usar -h:
>   ```bash
>   touch -t 202506012047 test0
>   touch -t 202506012146 test1
>   touch -t 202506012245 test2
>   touch -t 202506012344 test3
>   touch -t 202506012343 test4
>   touch -h -t 202506012220 test6
>   ```
> 
>6. ahora cambiaremos los permisos de los archivos:
> 
>   ```bash
>   chmod u=rwx,g=x,o=rx test0
>   chmod u=rwx,g=x,o=r test1
>   chmod u=rx,g=x,o=r test2
>   chmod u=r,g=,o=r test3
>   chmod u=rw,g=r,o=x test4
>   chmod u=rwx,g=rx,o=rx test6
>   ```
>7. Ahora crearemos un hardlink para de test3 -> test5:
>
>   ```bash
>   ln test3 test5
>   ```
> 
>8. Ahora comprimimos el archivo con el comando que nos indica el enuncidado:
> 
>   ```bash
>   tar -cf exo2.tar *
>   ```
>9. Ahora borramos los archivos para dejar el directorio como nos lo pide el ejercicio:
> 
>   ```bash
>   rm -fr test*
>   ```

